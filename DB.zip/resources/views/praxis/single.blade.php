@extends('layouts.praxis')
@section('contant')

     <!--===================================Category list start===================================-->
  


  <div class="shadow-lg p-3 mb-5 bg-white rounded praxis-sb-subcat ">
    <!--  subcategory-1 -->
    <div class="accordion" id="accordionExample">
      <div class="card">
        <div class="card-header " id="headingTwo">
            <div class="d-flex bd-highlight">
                <div class="p-2 w-100 bd-highlight">
                    <h3 class="btn btn-link collapsed"  data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="false" aria-controls="collapseTwo">
                    <i data-v-7a1def25="" class="flaticon-download collapse-icon-img collapse-icon web" style="display: inline;"></i> Collapsible Group Item #2
                </h3>
                </div>
                <div class="p-2 flex-shrink-1 bd-highlight"><a  data-toggle="modal" class="btn btn-primary"  st data-target="#exampleModal">
                    add
                </a></div>
              </div>
          <!-- collapse value -->
              <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                <div class="card-body">
                  Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon
                  officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod.
                  <br>
                  <a data-toggle="modal" data-target="#exampleModa2" href="">view details</a>     
               </div>
              </div>   
        </div>        
      </div>
    </div>
    <!-- subcategory-2 -->

    <div class="accordion" id="accordionExample2">
      <div class="card">
        <div class="card-header " id="headingTwo1">
            <div class="d-flex bd-highlight">
                <div class="p-2 w-100 bd-highlight">
                    <h3 class="btn btn-link collapsed"  data-toggle="collapse" data-target="#collapseTwo1"
                    aria-expanded="false" aria-controls="collapseTwo">
                    <i data-v-7a1def25="" class="flaticon-download collapse-icon-img collapse-icon web" style="display: inline;"></i> Collapsible Group Item #2
                </h3>
                </div>
                <div class="p-2 flex-shrink-1 bd-highlight"><a  data-toggle="modal" class="btn btn-primary"  st data-target="#exampleModal">
                    add
                </a></div>
              </div>
          <!-- collapse value -->
              <div id="collapseTwo1" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample2">
                <div class="card-body">
                  Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon
                  officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod.
                  <br>
                  <a data-toggle="modal" data-target="#exampleModa2" href="">view details</a>     
               </div>
              </div>   
        </div>        
      </div>
    </div>
     </div>



  

  <!--===================================Category list end===================================-->

  <!-- Modal-1 -->
  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Service Option</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <p>Choose Your Facial</p>
          <select name="" id="" class="form-control">
            <option value="">select</option>
            <option value="">select</option>
            <option value="">select</option>
 
 
          </select>
         
         <p>Choose Your Add-on</p>
         <select name="" id="" class="form-control">
           <option value="">select</option>
           <option value="">select</option>
           <option value="">select</option>


         </select>
         <p>Quentity</p>
         <input class="form-control" type="number">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          
          <a href="serviceprovider.html" class="btn btn-primary">Next</a>
        </div>
      </div>
    </div>
  </div>

<!-- Modal-2 -->
  <div class="modal fade" id="exampleModa2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">
           service
          </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <img src="{{ asset('images/1552147923_moving_offices.png') }}" height="300px" width="100%" alt="">
        </div>
         <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Save changes</button>
        </div> 
      </div>
    </div>
  </div>
@endsection
@section('extra_js')
<script src="{{ asset('assets/js/jquery3.0.1.js') }}"></script>
    
@endsection