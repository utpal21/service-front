<!DOCTYPE html>
<html lang="en">
<head>
	<title>IDB Laundry Services</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<meta name="keywords" content="Go Laundry Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>

	<!-- Bootstrap Core CSS -->
	<link href="<?php echo e(asset('assets/css/bootstrap.css')); ?>" rel='stylesheet' type='text/css' />
	<!-- gallery css -->
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/swipebox.css')); ?>">
	<!-- Custom CSS -->
	<link href="<?php echo e(asset('assets/css/style.css')); ?>" rel='stylesheet' type='text/css' />
	<!-- Custom CSS inportant -->
	<link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel='stylesheet' type='text/css' />
	<!-- font-awesome icons -->
	<link href="<?php echo e(asset('assets/css/fontawesome-all.min.css')); ?>" rel="stylesheet">
	<!-- //Custom Theme files -->
	<!--webfonts-->
	<link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i"
	    rel="stylesheet">
	<!--//webfonts-->
	<style>
	.menu{
		height: 70px;
		background-color: white;
		
	}
	</style>
</head>

<body>
	<!-- header -->
	<header class="menu">
		<div class="fixed-top menu">
			<nav class="navbar navbar-expand-lg navbar-light ">
				<a class="navbar-brand" href="index.html">
					<i class="fab fa-empire"></i>
				</a>
				<button class="navbar-toggler ml-md-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
				    aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>

				<div class="collapse navbar-collapse " id="navbarSupportedContent">
					<ul class="navbar-nav mx-auto text-center">
						<li class="nav-item active  mr-3">
							<a class="nav-link" href="index.html">হোম
								<span class="sr-only">(current)</span>
							</a>
						</li>
						<li class="nav-item  mr-3">
							<a class="nav-link scroll" href="#about">আমাদের-সেবাসমূহ</a>
						</li><li class="nav-item  mr-3">
							<a class="nav-link scroll" href="#services">কার্যাবলী</a>
						</li><li class="nav-item  mr-3">
							<a class="nav-link scroll" href="#pricing">মূল্য তালিকা</a>
						</li><li class="nav-item  mr-3">
							<a class="nav-link scroll" href="#pakage">প্যাকেজ</a>
						</li><li class="nav-item  mr-3">
							<a class="nav-link scroll" href="#team">টীম</a>
						</li><li class="nav-item  mr-3">
							<a class="nav-link scroll" href="#gallery">গ্যালারি</a>
						</li><li class="nav-item  mr-3">
							<a class="nav-link scroll" href="#testimonials">সত্যাতা</a>
						</li>
						<!-- <li class="nav-item dropdown mr-3">
							<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
							    aria-expanded="false">
								Dropdown
							</a>
							<div class="dropdown-menu" aria-labelledby="navbarDropdown">
								<a class="dropdown-item scroll" href="#services">কার্যাবলী</a>
								<a class="dropdown-item scroll" href="#pricing">মূল্য তালিকা</a>
								<a class="dropdown-item scroll" href="#pakage">প্যাকেজ</a>
								<a class="dropdown-item scroll" href="#team">Team</a>
								<a class="dropdown-item scroll" href="#gallery">Gallery</a>
								<div class="dropdown-divider"></div>
								
								<a class="dropdown-item scroll" href="#testimonials">Testimonials</a>
							</div>
						</li> -->
						<li class="nav-item">
							<a class="nav-link scroll" href="#contact">যোগাযোগ</a>
						</li><li class="nav-item">
							<a class="nav-link scroll" href="#">লগইন/রেজিঃ</a>
						</li>
					</ul>
					

				</div>
			</nav>
		</div>
	</header>
	<!-- banner -->
	<!-- <div class="banner" id="home">
		<div class="container">
			<div class="banner-text text-center">
				<div class="callbacks_container">
					<ul class="rslides" id="slider3">
						<li>
							<div class="slider-info">
								<h3 class="text-capitalize">We care for all your valued garments </h3>
								<a class="btn btn-primary  mt-4 text-capitalize scroll" href="#about" role="button">read more</a>
							</div>
						</li>
						<li>
							<div class="slider-info">
								<h3 class="text-capitalize">Trust Us, We Save Your Time.</h3>
								<a class="btn btn-primary  mt-4 text-capitalize scroll" href="#about" role="button">read more</a>
							</div>
						</li>
						<li>
							<div class="slider-info">
								<h3 class="text-capitalize">we offer the best laundry services</h3>
								<a class="btn btn-primary  mt-4 text-capitalize scroll" href="#about" role="button">read more</a>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div> -->
	
	<!-- carosol -->
	<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
		<ol class="carousel-indicators">
		  <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
		  <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
		  <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
		</ol>
		<div class="carousel-inner">
		  <div class="carousel-item active">
			<img class="d-block w-100" src="<?php echo e(asset('assets/images/banner.jpg')); ?>" height="500px" alt="First slide">
			<div class="carousel-caption d-none d-md-block">
				<button type="button" class="btn btn-info btn-lg-block w3ls-btn px-4 text-uppercase font-weight-bold" data-toggle="modal"
					    aria-pressed="false" data-target="#exampleModal">
						order
					</button>
			  </div>
		  </div>
		  <div class="carousel-item">
			<img class="d-block w-100" src="<?php echo e(asset('assets/images/banner.jpg')); ?>" height="500px" alt="Second slide">
			<div class="carousel-caption d-none d-md-block">
				<button type="button" class="btn btn-info btn-lg-block w3ls-btn px-4 text-uppercase font-weight-bold" data-toggle="modal"
					    aria-pressed="false" data-target="#exampleModal">
						order
					</button>
			  </div>
		  </div>
		  <div class="carousel-item">
			<img class="d-block w-100" src="<?php echo e(asset('assets/images/banner.jpg')); ?>" height="500px" alt="Third slide">
			<div class="carousel-caption d-none d-md-block">
				<button type="button" class="btn btn-info btn-lg-block w3ls-btn px-4 text-uppercase font-weight-bold" data-toggle="modal"
					    aria-pressed="false" data-target="#exampleModal">
						order
					</button>
			  </div>
		  </div>
		</div>
		<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
		  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
		  <span class="sr-only">Previous</span>
		</a>
		<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
		  <span class="carousel-control-next-icon" aria-hidden="true"></span>
		  <span class="sr-only">Next</span>
		</a>
	  </div>
	  <marquee><h2>আমরা আপনাদের পোশাক অত্যন্ত সুন্দর ভাবে যত্ন নিয়ে থাকি। সময় বাঁচাতে আমাদের উপর নিশ্চিন্তে আস্থা রাখুন। আমরা সর্বোচ্চ সেবা দিতে বদ্ধ পরিকর। আমরা দিচ্ছি সুলভ মূল্যে সুন্দর সেবা যা অন্যান্য লন্ড্রি সেবা থেকে আরো উন্নত ম্যান সম্পন্ন।</h2></marquee>
	  <!-- carosul text when using text in this carosul image down -->
	  <!-- <div class="carousel-item">
		<img src="images/banner.jpg" alt="...">
		<div class="carousel-caption d-none d-md-block">
		  <h5>order now</h5>
		  <p>please order now</p>
		</div>
	  </div> -->
	<!-- carosol -->
	<!-- //banner -->
	<!-- about -->
	<section class="about-w3ls" id="about">
		<div class="container">
			<div class="jumbotron text-center pt-0">
				
				<h1 class="ab-title my-5">আমরা সর্বোচ্চ মানের যত্নের প্রতিশ্রুতি দিয়ে থাকি</h1>
				
				<h2 class="lead">Donec consequat sapien ut leo cursus rhoncus. Nullam dui mi, vulputate ac metus at, semper varius orci. Nulla accumsan
					ac elit in congue.</h2>
				<hr class="my-4">
				<p>rerum hic tenetur a sapiente delectus reiciendis maiores alias consequatur aut consequat sapien ut leo cursus rhoncus.
					Nullam dui mi, vulputate ac metus .</p>					
			</div>			
				<h3 class="w3ls-title text-center text-capitalize pb-md-5 pb-4">আমরা যে সব সেবা দিয়ে থাকি</h3>
				<div class="agileits-services-row row py-md-5 pb-5">
					<div class="col-lg-4 col-md-6 agileits-services-grids">
						<span class="fab fa-uniregistry p-4"></span>
						<h4 class="mt-2 mb-3">কর্পোরেট সেবা</h4>
						<p>আমাদের কর্পোরেট ক্লায়েন্টদের জন্য বিশেষ ব্যবস্থা রয়েছে যাদের দ্রুত এবং ভালো মানের সেবা প্রয়োজন</p>
					</div>
					<div class="col-lg-4 col-md-6 agileits-services-grids mt-md-0 mt-3">
						<span class="fab fa-jenkins p-4"></span>
						<h4 class="mt-2 mb-3">ধোয়া এবং ইস্ত্রি</h4>
						<p>সমস্ত ধরনের কাপড় ,গৃহস্থলীর ব্যবহারযোগ্য কাপড় আমরা সুন্দর ভাবে পরিষ্কার করি এবং ইস্ত্রি করি </p>
					</div>
	
					<div class="col-lg-4 col-md-6 agileits-services-grids mt-lg-0 mt-3">
						<span class="fab fa-schlix p-4"></span>
						<h4 class="mt-2 mb-3">শুষ্ক পরিস্কার সেবা</h4>
						<p>শুস্ক পরিষ্কারক সেবার মধ্যে দিয়ে আমরা আপনার কাপড়ের বিশেষ যত্নের আশ্বাস দিচ্ছি </p>
					</div>
					<div class="col-lg-4 col-md-6 agileits-services-grids mt-lg-0 mt-3">
						<span class="fas fa-magic p-4"></span>
						<h4 class="mt-2 mb-3">গৃহস্থালী কাপড়</h4>
						<p>অতি যত্ন সহকারে গৃহস্থলীর কাপড় পরিষ্কার করা হয়। বিছানার চাদর,টেবিলের কাপড় অতি যত্ন সহকারে পরিষ্কার করা হয়.যা এনেদেয় কাপড়ে নতুন চমক </p>
					</div>
					<div class="col-lg-4 col-md-6 agileits-services-grids mt-lg-0 mt-3">
						<span class="fas fa-magic p-4"></span>
						<h4 class="mt-2 mb-3">শাড়ি পলিশিং</h4>
						<p>শাড়ি পলিশিং এর জন্য আমাদের দক্ষ কারিগর আছে </p>
					</div>
					<div class="col-lg-4 col-md-6 agileits-services-grids mt-lg-0 mt-3">
						<span class="fas fa-magic p-4"></span>
						<h4 class="mt-2 mb-3">গৃহস্থালী কাপড়</h4>
						<p>অতি যত্ন সহকারে গৃহস্থলীর কাপড় পরিষ্কার করা হয়। বিছানার চাদর,টেবিলের কাপড় অতি যত্ন সহকারে পরিষ্কার করা হয়.যা এনেদেয় কাপড়ে নতুন চমক </p>
					</div>
				
				</div>
		</div>
	</section>
	<!-- //about -->
	<!--services-->
	<div class="agileits-services py-md-5 py-3" id="services">
		<div class="container">
			<h3 class="w3ls-title text-center text-capitalize pb-md-5 pb-4">কার্যাবলী</h3>
			<div class="agileits-services-row row py-md-5 pb-5">
				<div class="col-lg-3 col-md-6 agileits-services-grids">
					<span><img src="<?php echo e(asset('assets/images/img_icon_01.png')); ?>" class="img-responsive1" alt=""></span>
					<h4 class="mt-2 mb-3">অর্ডার</h4>
					<p>অনলাইনে অর্ডার করুন অথবা আমাদের হটলাইন কল করুন +৮৮০ ১৭৩৮-৩৫৬১৮০</p>
				</div>
				<div class="col-lg-3 col-md-6 agileits-services-grids mt-md-0 mt-3">
					<span><img src="<?php echo e(asset('assets/images/img_icon_02.png')); ?>" class="img-responsive1" alt=""></span>
					<h4 class="mt-2 mb-3">আমাদের সংগ্রহসমূহ</h4>
					<p>আপনার সুবিধামতো সময় এবং স্থান নির্বাচন করুন </p>
				</div>

				<div class="col-lg-3 col-md-6 agileits-services-grids mt-lg-0 mt-3">
					<span><img src="<?php echo e(asset('assets/images/img_icon_03.png')); ?>" class="img-responsive1" alt=""></span>
					<h4 class="mt-2 mb-3">আমরা পরিষ্কার করি</h4>
					<p>আমরা কাপড় পরিষ্কারের ক্ষেত্রে সর্বোচ্চ মান নিশ্চিত করি </p>
				</div>
				<div class="col-lg-3 col-md-6 agileits-services-grids mt-lg-0 mt-3">
					<span><img src="<?php echo e(asset('assets/images/img_icon_04.png')); ?>" class="img-responsive1" alt=""></span>
					<h4 class="mt-2 mb-3">আমরা সরবরাহ করি</h4>
					<p>আমরা আপনার সুবিধামতো কাপড় ডেলিভারি দিয়ে থাকি</p>
				</div>
			</div>
			<h3 class="text-center">জরুরী সেবা : "রকেট "(চব্বিশ ঘন্টায় ডেলিভারি  দেওয়া হয়  ) চার্জ নিয়মিত দামের চেয়ে দ্বিগুণ হবে</h3>
			
		</div>
	</div>
	<!-- //services--> 
	<!-- stats -->
	<section class="agile_stats text-center py-5">
		<div class="container pt-sm-5">
			<div class="stats_agile mb-sm-5 mb-3">
				<h3 class="stat-title text-capitalize pb-md-5 pb-4">let us do your laundry</h3>
			</div>
			<div class="row">
				<div class="col-lg-3 col-md-6">
					<div class="counter pt-5 px-3 pb-3">
						<i class="far fa-smile fa-2x"></i>
						<div class="timer count-title count-number mt-2" data-to="5100" data-speed="1500"></div>
						<p class="count-text text-capitalize">happy customers</p>
					</div>
				</div>
				<div class="col-lg-3 col-md-6 mt-md-0 mt-sm-5 mt-3">
					<div class="counter  pt-5 px-3 pb-3">
						<i class=" fab fa-stack-overflow fa-2x"></i>
						<div class="timer count-title count-number mt-2" data-to="4783" data-speed="1500"></div>
						<p class="count-text text-capitalize">dry clean</p>
					</div>
				</div>
				<div class="col-lg-3 col-md-6 mt-lg-0 mt-sm-5 mt-3">
					<div class="counter  pt-5 px-3 pb-3">
						<i class="fas fa-eraser fa-2x"></i>
						<div class="timer count-title count-number mt-2" data-to="2184" data-speed="1500"></div>
						<p class="count-text text-capitalize">ironing</p>
					</div>
				</div>
				<div class="col-lg-3 col-md-6 mt-lg-0  mt-sm-5 mt-3">
					<div class="counter  pt-5 px-3 pb-3">
						<i class="fas fa-exclamation fa-2x"></i>
						<div class="timer count-title count-number mt-2" data-to="1084" data-speed="1084"></div>
						<p class="count-text text-capitalize">stain removal</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- //stats -->
	<!-- pricing -->
	<section class="container-fluid section-star " id="pricing">
		<div class="container">
			<h3 class="w3ls-title text-center text-capitalize pb-md-5 pb-4">মূল্য</h3>
			<div class="row pb-5">
					<div class="col-lg-4 col-md-4 pb-0 pt-3 px-3 agile-pricegrid">
							<div class="pricing-box">
								<div class="plan-header">	
									<h2>ছেলেদের পোশাক</h2>												
								</div>
								<div class="plan-inside">
									<table class="table table-bordered table-condensed table-hover">
										<thead>
											<tr class="table_head">
												<th class="text-center">তালিকা</th>
												<th class="text-center">ধোয়া</th>
												<th class="text-center">শুকনোভাবে পরিস্কার</th>
												<th class="text-center">ইস্ত্রি</th>
											</tr>
										</thead>
										<tbody>
																				<tr>
												<td>শার্ট</td>
												<td>৫০</td>
												<td>৬০</td>
												<td>১০</td>
											</tr>
																				<tr>
												<td>প্যান্ট</td>
												<td>৫০</td>
												<td>৬০</td>
												<td>১০</td>
											</tr>
																				<tr>
												<td>টি- শার্ট</td>
												<td>৫০</td>
												<td>৬০</td>
												<td>১০</td>
											</tr>
																				<tr>
												<td>সুতি পাঞ্জাবি</td>
												<td>৫০</td>
												<td>৬৫</td>
												<td>১০</td>
											</tr>
																				<tr>
												<td>পাঞ্জাবি সিল্ক</td>
												<td>৫০</td>
												<td>৮০</td>
												<td>১০</td>
											</tr>
																				<tr>
												<td>পাঞ্জামা </td>
												<td>৫০</td>
												<td>৬০</td>
												<td>১০</td>
											</tr>
																				<tr>
												<td>সোয়েটার</td>
												<td>১০০</td>
												<td>১৩০</td>
												<td>৩০</td>
											</tr>
																				<tr>
												<td>জ্যাকেট</td>
												<td>১৩০</td>
												<td>১৫০</td>
												<td>৩০</td>
											</tr>
																				<tr>
												<td>সাফারি সেট</td>
												<td>৯০</td>
												<td>১১০</td>
												<td>৪০</td>
											</tr>
																				<tr>
												<td>ব্লেজার</td>
												<td>0</td>
												<td>১৬০</td>
												<td>৫০</td>
											</tr>
																				<tr>
												<td>কোমর কোট</td>
												<td>0</td>
												<td>৬০</td>
												<td>২৫</td>
											</tr>
																				<tr>
												<td>লুঙ্গি</td>
												<td>৪০</td>
												<td>০</td>
												<td>১০</td>
											</tr>
																				<tr>
												<td>শেরওয়ানি</td>
												<td>০</td>
												<td>৩৫০</td>
												<td>৮০</td>
											</tr>
																				
										</tbody>
									</table>
								</div>
							</div>
						</div>

						<div class="col-lg-4 col-md-4 pb-0 pt-3 px-3 agile-pricegrid">
								<div class="pricing-box">
									<div class="bg-price py-sm-3 rounded-top text-center">	
										<h2>মহিলাদের পোশাক</h2>												
									</div>
									<div class="plan-inside">
										<table class="table table-bordered table-condensed table-hover">
											<thead>
												<tr class="table_head">
													<th class="text-center">তালিকা</th>
													<th class="text-center">ধোয়া</th>
													<th class="text-center">শুকনোভাবে পরিস্কার</th>
													<th class="text-center">ইস্ত্রি</th>
												</tr>
											</thead>
											<tbody>
																					<tr>
													<td>সুতি কামিজ</td>
													<td>৫০</td>
													<td>৬০</td>
													<td>১০</td>
												</tr>
																					<tr>
													<td>কামিজ সিল্ক </td>
													<td>০</td>
													<td>৮০</td>
													<td>১০</td>
												</tr>
																					<tr>
													<td>সালোয়ার</td>
													<td>৫০</td>
													<td>৬০</td>
													<td>১০</td>
												</tr>
																					<tr>
													<td>ব্লাউজ</td>
													<td>৪০</td>
													<td>৫০</td>
													<td>১০</td>
												</tr>
																					<tr>
													<td>সুতি শাড়ি </td>
													<td>১২০</td>
													<td>১৪০</td>
													<td>৫০</td>
												</tr>
																					<tr>
													<td>শাড়ি কাতান</td>
													<td>০</td>
													<td>২৫০</td>
													<td>৬০</td>
												</tr>
																					<tr>
													<td>জামদানি শাড়ি</td>
													<td>০</td>
													<td>২০০</td>
													<td>৭০</td>
												</tr>
																					<tr>
													<td>সিল্ক শাড়ি</td>
													<td>০</td>
													<td>১৮০</td>
													<td>৬০</td>
												</tr>
																					<tr>
													<td>দুপাট্টা</td>
													<td>৪০</td>
													<td>৫০</td>
													<td>১০</td>
												</tr>
																					<tr>
													<td>বোরকা</td>
													<td>০</td>
													<td>৬০</td>
													<td>১০</td>
												</tr>
																					
											</tbody>
										</table>
									</div>
								</div>
							</div>	
				
							<div class="col-lg-4 col-md-4 pb-0 pt-3 px-3 agile-pricegrid">
								<div class="pricing-box">
									<div class="bg-price py-sm-3 rounded-top text-center">	
										<h2>গৃহস্থালিসংক্রান্ত</h2>												
									</div>
									<div class="plan-inside">
										<table class="table table-bordered table-condensed table-hover">
											<thead>
												<tr class="table_head">
													<th class="text-center">তালিকা</th>
													<th class="text-center">ধোয়া</th>
													<th class="text-center">শুকনোভাবে পরিস্কার</th>
													<th class="text-center">ইস্ত্রি</th>
												</tr>
											</thead>
											<tbody>
																					<tr>
													<td>িবছানা চাদর</td>
													<td>৯০</td>
													<td>১১০</td>
													<td>২০</td>
												</tr>
																					<tr>
													<td>Cartain (per Kuchi)</td>
													<td>20</td>
													<td>25</td>
													<td>8</td>
												</tr>
																					<tr>
													<td>Blanket (s)</td>
													<td>0</td>
													<td>300</td>
													<td>0</td>
												</tr>
																					<tr>
													<td>Blanket (L)</td>
													<td>0</td>
													<td>350</td>
													<td>0</td>
												</tr>
																					<tr>
													<td>kantha</td>
													<td>200</td>
													<td>0</td>
													<td>0</td>
												</tr>
																					<tr>
													<td>pillow case</td>
													<td>40</td>
													<td>45</td>
													<td>0</td>
												</tr>
																					<tr>
													<td>towel (s)</td>
													<td>80</td>
													<td>0</td>
													<td>0</td>
												</tr>
																					<tr>
													<td>towel (L)</td>
													<td>100</td>
													<td>0</td>
													<td>0</td>
												</tr>
																					<tr>
													<td>Quilt</td>
													<td>200</td>
													<td>250</td>
													<td>0</td>
												</tr>
																					<tr>
													<td>Blanket cover</td>
													<td>110</td>
													<td>130</td>
													<td>0</td>
												</tr>
																					<tr>
													<td>Table Cloth</td>
													<td>60</td>
													<td>75</td>
													<td>10</td>
												</tr>
																					<tr>
													<td>Sofa/seat cover</td>
													<td>80</td>
													<td>100</td>
													<td>15</td>
												</tr>
																					<tr>
													<td>Mosquito Net </td>
													<td>60</td>
													<td>0</td>
													<td>0</td>
												</tr>
																					
											</tbody>
										</table>
									</div>
								</div>
							</div>

						<!-- টেবিল -->
				
			</div>
		</div>
	</section>
	<!-- //pricing -->
	<!-- pakage -->
	<section class="wthree-row py-md-5 pt-sm-5" id="pakage">
		<div class="container py-md-5 py-3">
			<h3 class="w3ls-title text-center text-capitalize pb-md-5 pb-4">আমাদের প্যাকেজ সমূহঃ-
			</h3>
			<div class="row pb-5">
					<div class="col-lg-4 col-md-6 text-center pb-0 pt-3 px-3 agile-pricegrid">
							<div class="bg-price py-sm-3 rounded-top text-center">
								<h4>পারিবারিক লন্ড্রী প্যাকেজ</h4>
								<span class="mx-auto my-2"></span>
							</div>
							<div class="p-3">
									<img src="<?php echo e(asset('assets/images/14726476122.jpg')); ?>" alt="">
								<h5 class="pt-2">
										<sup>প্রতিমাসে</sup>৬৪০৳</h5>
										<span>৪০ পিছ</span>
							</div>
							<ul class="list-group-flush">
									<li class="list-group-item">নিয়মিত মূল্য <strong>৮০০৳</strong></li>
									<li class="list-group-item">বিশেষ ছাড় <strong> ৬৪০০০৳</strong> </li>
									<li class="list-group-item">আপনি পাচ্ছেন <strong>১৬০৳ ছাড়</strong> </li>
									<li class="list-group-item"><strong>৩০</strong> দিন</li>
							</ul>
							<div class="py-3 px-2">
								<button type="button" class="btn btn-info btn-lg btn-block" data-toggle="modal" aria-pressed="false" data-target="#exampleModal">Get Started</button>
							</div>
						</div>
				<div class="col-lg-4 col-md-6 text-center pb-0 pt-3 px-3 agile-pricegrid">
					<div class="bg-price py-sm-3 rounded-top text-center">
						<h4>দম্পত্তির  লন্ড্রি প্যাকেজ</h4>
						<span class="mx-auto my-2"></span>
					</div>
					<div class="p-3">
							<img src="<?php echo e(asset('assets/images/1472647652.jpg')); ?>" alt="">
						<h5 class="pt-2">
								<sup>প্রতিমাসে</sup>৪০০৳</h5>
								<span>৫০ পিছ</span>
					</div>
					<ul class="list-group-flush">
							<li class="list-group-item">নিয়মিত মূল্য <strong>৫০০৳</strong></li>
							<li class="list-group-item">বিশেষ ছাড় <strong> ৪০০৳</strong> </li>
							<li class="list-group-item">আপনি পাচ্ছেন <strong>১০০৳ ছাড়</strong> </li>
							<li class="list-group-item"><strong>৩0 </strong> দিন</li>
					</ul>
					<div class="py-3 px-2">
						<button type="button" class="btn btn-info btn-lg btn-block" data-toggle="modal" aria-pressed="false" data-target="#exampleModal">Get Started</button>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 text-center pb-0 pt-3 px-3 agile-pricegrid">
						<div class="bg-price py-sm-3 rounded-top text-center">
							<h4>একক লন্ড্রি প্যাকেজ</h4>
							<span class="mx-auto my-2"></span>
						</div>
						<div class="p-3">
								<img src="<?php echo e(asset('assets/images/1472647585.jpg')); ?>" alt="">
							<h5 class="pt-2">
									<sup>প্রতিমাসে</sup>২৪০৳</h5>
									<span>৩০ পিছ</span>
						</div>
						<ul class="list-group-flush">
								<li class="list-group-item">নিয়মিত মূল্য <strong>৩০০৳</strong></li>
								<li class="list-group-item">বিশেষ ছাড় <strong> ২৪০৳</strong> </li>
								<li class="list-group-item">আপনি পাচ্ছেন <strong>৬০৳ ছাড়</strong> </li>
								<li class="list-group-item"><strong>৩0 </strong> দিন</li>
						</ul>
						<div class="py-3 px-2">
							<button type="button" class="btn btn-info btn-lg btn-block" data-toggle="modal" aria-pressed="false" data-target="#exampleModal">Get Started</button>
						</div>
					</div>
					<div class="col-lg-4 col-md-6 text-center pb-0 pt-3 px-3 agile-pricegrid">
							<div class="bg-price py-sm-3 rounded-top text-center">
								<h4>একক ওয়াশিং প্যাক</h4>
								<span class="mx-auto my-2"></span>
							</div>
							<div class="p-3">
									<img src="<?php echo e(asset('assets/images/1472648785.jpg')); ?>" alt="">
								<h5 class="pt-2">
										<sup>প্রতিমাসে</sup>৫৯৯৳</h5>
										<span>১৫ পিছ</span>
							</div>
							<ul class="list-group-flush">
									<li class="list-group-item">নিয়মিত মূল্য <strong>৭৫০৳</strong></li>
									<li class="list-group-item">বিশেষ ছাড় <strong>৫৯৯৳</strong> </li>
									<li class="list-group-item">আপনি পাচ্ছেন <strong>১৫১৳ ছাড়</strong> </li>
									<li class="list-group-item"><strong>৩0 </strong> দিন</li>
							</ul>
							<div class="py-3 px-2">
								<button type="button" class="btn btn-info btn-lg btn-block" data-toggle="modal" aria-pressed="false" data-target="#exampleModal">Get Started</button>
							</div>
						</div>
						<div class="col-lg-4 col-md-6 text-center pb-0 pt-3 px-3 agile-pricegrid">
								<div class="bg-price py-sm-3 rounded-top text-center">
									<h4>দম্পতি ওয়াশিং প্যাক</h4>
									<span class="mx-auto my-2"></span>
								</div>
								<div class="p-3">
										<img src="<?php echo e(asset('assets/images/1472648829.jpg')); ?>" alt="">
									<h5 class="pt-2">
											<sup>প্রতিমাসে</sup>৯৯৯৳</h5>
											<span>২৫ পিছ</span>
								</div>
								<ul class="list-group-flush">
										<li class="list-group-item">নিয়মিত মূল্য <strong>১২৫০৳</strong></li>
										<li class="list-group-item">বিশেষ ছাড় <strong>৯৯৯৳</strong> </li>
										<li class="list-group-item">আপনি পাচ্ছেন <strong>২৫১৳ ছাড়</strong> </li>
										<li class="list-group-item"><strong>৩0 </strong> দিন</li>
								</ul>
								<div class="py-3 px-2">
									<button type="button" class="btn btn-info btn-lg btn-block" data-toggle="modal" aria-pressed="false" data-target="#exampleModal">Get Started</button>
								</div>
							</div>
							<div class="col-lg-4 col-md-6 text-center pb-0 pt-3 px-3 agile-pricegrid">
									<div class="bg-price py-sm-3 rounded-top text-center">
										<h4>পারিবারিক ওয়াশিং প্যাক</h4>
										<span class="mx-auto my-2"></span>
									</div>
									<div class="p-3">
											<img src="<?php echo e(asset('assets/images/1472648868.jpg')); ?>" alt="">
										<h5 class="pt-2">
												<sup>প্রতিমাসে</sup>১৯৯৯৳</h5>
												<span>৫০ পিছ</span>
									</div>
									<ul class="list-group-flush">
											<li class="list-group-item">নিয়মিত মূল্য <strong>২৫০০৳</strong></li>
											<li class="list-group-item">বিশেষ ছাড় <strong>১৯৯৯৳</strong> </li>
											<li class="list-group-item">আপনি পাচ্ছেন <strong>৫০১৳ ছাড়</strong> </li>
											<li class="list-group-item"><strong>৩0 </strong> দিন</li>
									</ul>
									<div class="py-3 px-2">
										<button type="button" class="btn btn-info btn-lg btn-block" data-toggle="modal" aria-pressed="false" data-target="#exampleModal">Get Started</button>
									</div>
								</div>
			</div>
		</div>
	</section>
	<!-- // pakage-->
	<!-- team -->
	<section class="wthree-row py-5" id="team">
		<div class="container py-md-5 py-3">
			<div class="py-md-5 py-3 bg-pricemain text-center">
				<h3 class="w3ls-title text-center text-capitalize pb-md-5 pb-4">meet our team</h3>
			</div>
			<div class="row">
				<div class="col-lg-3 col-sm-6 team-grids">
					<div class="team-effect">
						<img src="<?php echo e(asset('assets/images/t1.jpg')); ?>" alt="img" class="img-responsive">
					</div>
					<!-- team text -->
					<div class="footerv2-w3ls mt-3">
						<h4>John Smith</h4>
						<p>Creative Director</p>
						<ul class="social-iconsv2 agileinfo">
							<li>
								<a href="#">
									<i class="fab fa-facebook-f"></i>
								</a>
							</li>
							<li>
								<a href="#">
									<i class="fab fa-twitter"></i>
								</a>
							</li>
							<li>
								<a href="#">
									<i class="fab fa-google-plus-g"></i>
								</a>
							</li>
							<li>
								<a href="#">
									<i class="fab fa-linkedin-in"></i>
								</a>
							</li>
						</ul>
					</div>
					<!-- //team text -->
				</div>
				<div class="col-lg-3 col-sm-6 team-grids mt-sm-0 mt-5">
					<div class="team-effect">
						<img src="<?php echo e(asset('assets/images/t3.jpg')); ?>" alt="img" class="img-responsive">
					</div>
					<!-- team text -->
					<div class="footerv2-w3ls mt-3">
						<h4>Thomson Doe</h4>
						<p>Chairman</p>
						<ul class="social-iconsv2 agileinfo">
							<li>
								<a href="#">
									<i class="fab fa-facebook-f"></i>
								</a>
							</li>
							<li>
								<a href="#">
									<i class="fab fa-twitter"></i>
								</a>
							</li>
							<li>
								<a href="#">
									<i class="fab fa-google-plus-g"></i>
								</a>
							</li>
							<li>
								<a href="#">
									<i class="fab fa-linkedin-in"></i>
								</a>
							</li>
						</ul>
					</div>
					<!-- //team text -->
				</div>
				<div class="col-lg-3 col-sm-6 team-grids mt-lg-0 mt-5">
					<div class="team-effect">
						<img src="<?php echo e(asset('assets/images/t2.jpg')); ?>" alt="img" class="img-responsive">
					</div>
					<!-- team text -->
					<div class="footerv2-w3ls mt-3">
						<h4>Smith Kevin</h4>
						<p>Executive Manager</p>
						<ul class="social-iconsv2 agileinfo">
							<li>
								<a href="#">
									<i class="fab fa-facebook-f"></i>
								</a>
							</li>
							<li>
								<a href="#">
									<i class="fab fa-twitter"></i>
								</a>
							</li>
							<li>
								<a href="#">
									<i class="fab fa-google-plus-g"></i>
								</a>
							</li>
							<li>
								<a href="#">
									<i class="fab fa-linkedin-in"></i>
								</a>
							</li>
						</ul>
					</div>
					<!-- //team text -->
				</div>
				<div class="col-lg-3 col-sm-6 team-grids mt-lg-0 mt-5">
					<div class="team-effect">
						<img src="<?php echo e(asset('assets/images/t4.jpg')); ?>" alt="img" class="img-responsive">
					</div>
					<!-- team text -->
					<div class="footerv2-w3ls mt-3">
						<h4>Laura Hill</h4>
						<p>HR Manager</p>
						<ul class="social-iconsv2 agileinfo">
							<li>
								<a href="#">
									<i class="fab fa-facebook-f"></i>
								</a>
							</li>
							<li>
								<a href="#">
									<i class="fab fa-twitter"></i>
								</a>
							</li>
							<li>
								<a href="#">
									<i class="fab fa-google-plus-g"></i>
								</a>
							</li>
							<li>
								<a href="#">
									<i class="fab fa-linkedin-in"></i>
								</a>
							</li>
						</ul>
					</div>
					<!-- //team text -->
				</div>
			</div>
		</div>
	</section>
	<!-- //team -->
	<!-- gallery -->
	<div class="gallery  py-md-5 py-3" id="gallery">
		<div class="container">
			<h3 class="w3ls-title text-center text-capitalize py-md-4 py-3">gallery</h3>
			<div class="gallery_gds row pt-md-5 pt-3">
				<div class="col-4 gal-w3l">
					<div class="agileits-img">
						<a href="<?php echo e(asset('assets/images/g1.jpg')); ?>" class="swipebox" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
							<img class="img-responsive img-style row2" src="<?php echo e(asset('assets/images/g1.jpg')); ?>" alt="" />
						</a>
					</div>
				</div>
				<div class="col-4  gal-w3l">
					<div class="agileits-img">
						<a href="<?php echo e(asset('assets/images/g2.jpg')); ?>" class="swipebox" title="Duis maximus tortor diam, ac lobortis justo rutrum quis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent non purus fermentum, eleifend velit non">
							<img src="<?php echo e(asset('assets/images/g2.jpg')); ?>" alt="" class="img-responsive img-style row2" />
						</a>
					</div>
				</div>
				<div class="col-4  gal-w3l">
					<div class="agileits-img">
						<a href="<?php echo e(asset('assets/images/g3.jpg')); ?>" class="swipebox" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
							<img src="<?php echo e(asset('assets/images/g3.jpg')); ?>" alt="" class="img-responsive img-style row2" />
						</a>
					</div>
				</div>
			</div>
			<div class="gallery_gds row">
				<div class="col-4  gal-w3l">
					<div class="agileits-img">
						<a href="<?php echo e(asset('assets/images/g4.jpg')); ?>" class="swipebox" title="Praesent non purus fermentum, eleifend velit non Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis.">
							<img src="<?php echo e(asset('assets/images/g4.jpg')); ?>" alt="" class="img-responsive img-style row2" />
						</a>
					</div>
				</div>
				<div class="col-4  gal-w3l">
					<div class="agileits-img">
						<a href="<?php echo e(asset('assets/images/g5.jpg')); ?>" class="swipebox" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
							<img src="<?php echo e(asset('assets/images/g5.jpg')); ?>" alt="" class="img-responsive img-style row2" />
						</a>
					</div>
				</div>
				<div class="col-4  gal-w3l">
					<div class="agileits-img">
						<a href="<?php echo e(asset('assets/images/g6.jpg')); ?>" class="swipebox" title="Duis maximus tortor diam, ac lobortis justo rutrum quis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent non purus fermentum, eleifend velit non">
							<img src="<?php echo e(asset('assets/images/g6.jpg')); ?>" alt="" class="img-responsive img-style row2" />
						</a>
					</div>
				</div>
			</div>
			<div class="row pb-md-5 pb-3">
				<div class="col-4  gal-w3l">
					<div class="agileits-img">
						<a href="<?php echo e(asset('assets/images/g7.jpg')); ?>" class="swipebox" title="Praesent non purus fermentum, eleifend velit non Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis.">
							<img src="<?php echo e(asset('assets/images/g7.jpg')); ?>" alt="" class="img-responsive img-style row2" />
						</a>
					</div>
				</div>
				<div class="col-4  gal-w3l">
					<div class="agileits-img">
						<a href="<?php echo e(asset('assets/images/g8.jpg')); ?>" class="swipebox" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
							<img src="<?php echo e(asset('assets/images/g8.jpg')); ?>" alt="" class="img-responsive img-style row2" />
						</a>
					</div>
				</div>
				<div class="col-4  gal-w3l">
					<div class="agileits-img">
						<a href="<?php echo e(asset('assets/images/g9.jpg')); ?>" class="swipebox" title="Duis maximus tortor diam, ac lobortis justo rutrum quis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent non purus fermentum, eleifend velit non">
							<img src="<?php echo e(asset('assets/images/g9.jpg')); ?>" alt="" class="img-responsive img-style row2" />
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- //gallery -->
	
	<!-- testimonials -->
	<section class="wthree-row py-5 testi-agile" id="testimonials">
		<div class="container py-md-5 py-3">
			<h3 class="w3ls-title text-center text-capitalize pb-md-5 pb-4">testimonials</h3>
			<div class="w3_testimonials_grids w3_testimonials_grids">
				<div class="sreen-gallery-cursual">
					<div id="owl-demo" class="owl-carouselpb-5">
						<div class="item-owl text-center">
							<div class="img-agile">
								<i class="fas fa-user"></i>
								<h6 class="mt-3 text-white">Michael Paul</h6>
							</div>
							<div class="test-review test-tooltip1">
								<p class="mx-auto mt-3 text-white">
									<i class="fa fa-quote-left" aria-hidden="true"></i> Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat,
									sed diam voluptua.
									<i class="fa fa-quote-right" aria-hidden="true"></i>
								</p>
							</div>
						</div>
						<div class="item-owl">
							<div class="img-agile">
								<i class="fas fa-user"></i>
								<h6 class="mt-3 text-white">Riya Allen</h6>
							</div>
							<div class="test-review test-tooltip1">
								<p class="mx-auto mt-3 text-white">
									<i class="fa fa-quote-left" aria-hidden="true"></i> Polite sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed
									diam voluptua.
									<i class="fa fa-quote-right" aria-hidden="true"></i>
								</p>
							</div>
						</div>
						<div class="item-owl">
							<div class="img-agile">
								<i class="fas fa-user"></i>
								<h6 class="mt-3 text-white">Riya Allen</h6>
							</div>
							<div class="test-review test-tooltip1">
								<p class="mx-auto mt-3 text-white">
									<i class="fa fa-quote-left" aria-hidden="true"></i> Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat,
									sed diam voluptua.
									<i class="fa fa-quote-right" aria-hidden="true"></i>
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- //testimonials -->
	<!-- contact -->
	<section class="wthree-row py-5 w3-contact" id="contact">
		<div class="container py-md-5">
			<h3 class="w3ls-title text-center text-capitalize pb-md-5 pb-4">contact us</h3>
			<div class="row contact-form py-3">
				<div class="col-lg-6 wthree-form-left">
					<!-- contact form grid -->
					<div class="contact-top1">
						<form action="#" method="get" class="f-color">
							<div class="form-group">
								<label for="contactusername">Name</label>
								<input type="text" class="form-control" id="contactusername" required>
							</div>
							<div class="form-group">
								<label for="contactemail">Email</label>
								<input type="email" class="form-control" id="contactemail" required>
							</div>
							<div class="form-group">
								<label for="contactcomment">Your Message</label>
								<textarea class="form-control" rows="5" id="contactcomment" required></textarea>
							</div>
							<button type="submit" class="btn btn-info btn-block">Submit</button>
						</form>
					</div>
					<!--  //contact form grid ends here -->
				</div>
				<!-- contact details -->
				<!-- contact map grid -->
				<div class="col-lg-6  mt-lg-0 mt-5 map contact-right">
					<iframe class="h-50" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3023.9503398796587!2d-73.9940307!3d40.719109700000004!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a27e2f24131%3A0x64ffc98d24069f02!2sCANADA!5e0!3m2!1sen!2sin!4v1441710758555"
					    allowfullscreen></iframe>
					<div class="address mt-3">
						<h5 class="pb-3 text-capitalize">Contact info</h5>
						<address>
							<p class="c-txt">90 Street, City, State 34789.</p>
							<p>
								+৮৮০১৭৩৮৩৫৬১৮০</p>
							<p>
								<p>
									<a href="mailto:info@creative.com">info@creativeitbari.com</a>
								</p>
						</address>
					</div>
				</div>
				<!--//contact map grid ends here-->
			</div>
			<!-- //contact details container -->
		</div>
	</section>
	<!-- //contact -->
	<!-- slide -->
	<section class="wthree-row py-sm-5 py-3 slide-bg bg-dark">
		<div class="container py-md-5 py-3">
			<div class="py-lg-5 bg-pricemain">
				<h3 class="agile-title text-capitalize text-white">go laundry!</h3>
				<span class="w3-line"></span>
				<h5 class="agile-title text-capitalize pt-4">trust us, we save your time.</h5>
				<p class="text-light py-sm-4 py-2">Aliquam ac est vel nisl condimentum interdum vel eget enim. Curabitur mattis orci sed leo mattis, nec maximus nibh faucibus.
					Mauris et justo vel nibh rhoncus venenatis. Nullal condimentum interdum vel eget enim. Curabitur mattis orci sed le.
				</p>
				<a href="#" class="text-uppercase serv_link align-self-center bg-light btn px-4">read more</a>
			</div>
		</div>
	</section>
	<!--//slide-->
	<!-- footer -->
	<footer class="py-md-5 pt-5 pb-4">
		<div class="container">
			<!-- footer grid top -->
			<div class="footerv2-w3ls text-center">
				<h4 class="w3ls-title text-capitalize pb-3">socialize with us</h4>
				<ul class="social-iconsv2 agileinfo mt-3">
					<li>
						<a href="#">
							<i class="fab fa-facebook-f"></i>
						</a>
					</li>
					<li>
						<a href="#">
							<i class="fab fa-twitter"></i>
						</a>
					</li>
					<li>
						<a href="#">
							<i class="fab fa-google-plus-g"></i>
						</a>
					</li>
					<li>
						<a href="#">
							<i class="fab fa-linkedin-in"></i>
						</a>
					</li>
				</ul>
				<div class="fv3-contact mt-3">
					<span class="fas fa-envelope-open mr-2"></span>
					<p>
						<a href="mailto:info@creativeitbari.com" class="text-dark">info@creativeitbari.com</a>
					</p>
				</div>
				<div class="fv3-contact">
					<span class="fas fa-phone-volume mr-2"></span>
					<p>+88 01738356180</p>
				</div>
			</div>
			<!-- copyright -->
			<div class="cpy-right text-center pt-5">
				<p>© 2019 IDB Laundry. All rights reserved | Design by
					<a href="http://creativeitbari.com"> CreativeITbari.</a>
				</p>
			</div>
			<!-- //copyright -->
		</div>
	</footer>
	<!-- //footer -->
	<!-- order modal -->
	<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title text-capitalize" id="exampleModalLabel1">order your laundry</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="#" method="post" class="p-3">
						<div class="form-group">
							<label for="recipient-name" class="col-form-label">Your Name</label>
							<input type="text" class="form-control" placeholder=" " name="Name" id="recipient-name" required="">
						</div>
						<div class="form-group">
							<label for="recipient-name1" class="col-form-label">Your Email</label>
							<input type="email" class="form-control" placeholder=" " name="Name" id="recipient-name1" required="">
						</div>
						<div class="form-group">
							<label for="recipient-name2" class="col-form-label">Phone</label>
							<input type="text" class="form-control" placeholder=" " name="Name" id="recipient-name2" required="">
						</div>
						<div class="form-group">
							<label class="mr-2 col-form-label">Pick Up</label>
							<input id="datepicker1" name="check in" type="text" value="mm/dd/yyyy" class="form-control" required="">
						</div>
						<div class="form-group">
							<label class="mr-2 col-form-label">Delivery </label>
							<input id="datepicker2" name="check out" type="text" value="mm/dd/yyyy" class="form-control" required="">
						</div>
						<div class="form-check">
							<label class="form-check-label col-form-label" for="l1">
								<input type="checkbox" class="form-check-input" value="" id="l1">Wash& Fold
							</label>
						</div>
						<div class="form-check">
							<label class="form-check-label col-form-label" for="l2">
								<input type="checkbox" class="form-check-input" value="" id="l2">Handwash
							</label>
						</div>
						<div class="form-check">
							<label class="form-check-label col-form-label" id="l3">
								<input type="checkbox" class="form-check-input" value="" id="13">Dry Clean
							</label>
						</div>
						<div class="form-check">
							<label class="form-check-label col-form-label" for="l4">
								<input type="checkbox" class="form-check-input" value="" id="l4">Carpets
							</label>
						</div>
						<div class="form-group">
							<label for="comment" class="col-form-label">Pickup Address:</label>
							<textarea class="form-control" rows="5" id="comment"></textarea>
						</div>

						<div class="right-w3l">
							<input type="submit" class="form-control" value="pick my laundry">
						</div>
					</form>

				</div>
			</div>
		</div>
	</div>
	<!-- //order modal -->

	<!-- js-->
	<script src="<?php echo e(asset('assets/js/jquery-2.2.3.min.js')); ?>"></script>
	<!-- js-->
	<!-- Banner text Responsiveslides -->
	<script src="<?php echo e(asset('assets/js/responsiveslides.min.js')); ?>"></script>
	<script>
		// You can also use "$(window).load(function() {"
		$(function () {
			// Slideshow 4
			$("#slider3").responsiveSlides({
				auto: true,
				pager: true,
				nav: false,
				speed: 500,
				namespace: "callbacks",
				before: function () {
					$('.events').append("<li>before event fired.</li>");
				},
				after: function () {
					$('.events').append("<li>after event fired.</li>");
				}
			});

		});
	</script>
	<!-- //Banner text  Responsiveslides -->
	<!-- start-smooth-scrolling -->
	<script src="<?php echo e(asset('assets/js/move-top.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/easing.js')); ?>"></script>
	<script>
		jQuery(document).ready(function ($) {
			$(".scroll ").click(function (event) {
				event.preventDefault();

				$('html,body').animate({
					scrollTop: $(this.hash).offset().top
				}, 1000);
			});
		});
	</script>
	<!-- //end-smooth-scrolling -->
	<!-- smooth-scrolling-of-move-up -->
	<script>
		$(document).ready(function () {
			/*
			 var defaults = {
				 containerID: 'toTop', // fading element id
				 containerHoverID: 'toTopHover', // fading element hover id
				 scrollSpeed: 1200,
				 easingType: 'linear' 
			 };
			 */

			$().UItoTop({
				easingType: 'easeOutQuart'
			});

		});
	</script>
	<script src="<?php echo e(asset('assets/js/SmoothScroll.min.js')); ?>"></script>
	<!-- //smooth-scrolling-of-move-up -->
	<!-- gallery swipebox -->
	<script src="<?php echo e(asset('js/jquery.swipebox.min.js')); ?>"></script>
	<script>
		jQuery(function ($) {
			$(".swipebox").swipebox();
		});
	</script>
	<script src="js/jquery.adipoli.min.js"></script>
	<!-- effect -->
	<script>
		$(function () {
			$('.row2').adipoli({
				'startEffect': 'overlay',
				'hoverEffect': 'sliceDown'
			});
		});
	</script>
	<!-- //swipe box js -->
	<!-- stats counter -->
	<script src="<?php echo e(asset('assets/js/counter.js')); ?>"></script>
	<!-- Date picker -->
	<link rel="stylesheet" href="<?php echo e(asset('css/jquery-ui.css')); ?>" />
	<script src="js/jquery-ui.js"></script>
	<script>
		$(function () {
			$("#datepicker1,#datepicker2").datepicker();
		});
	</script>
	<!-- // Date picker -->
	<!-- testimonials -->
	<link href="<?php echo e(asset('assets/css/owl.carousel.css')); ?>" rel="stylesheet">
	<script src="<?php echo e(asset('assets/js/owl.carousel.js')); ?>"></script>
	<script>
		$(document).ready(function () {
			$("#owl-demo").owlCarousel({
				items: 1,
				lazyLoad: true,
				autoPlay: false,
				navigation: true,
				navigationText: true,
				pagination: true,
			});
		});
	</script>
	<!-- //for testimonials slider-js-script-->
	<!-- Bootstrap Core JavaScript -->
	<script src="<?php echo e(asset('assets/js/bootstrap.js')); ?>">
	</script>
	<!-- //Bootstrap Core JavaScript -->
</body>

</html>