<?php $__env->startSection('contant'); ?>
    <div class="container responsive">
<h1>i am profils</h1>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>